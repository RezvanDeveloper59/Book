<?php
    $dir    = '../accez_folder/+989156247445/archive';
    $files1 = scandir($dir);
    //$files2 = scandir($dir, SCANDIR_SORT_DESCENDING);

    print_r($files1);
    //print_r($files2);
    //echo json_encode($files1);



